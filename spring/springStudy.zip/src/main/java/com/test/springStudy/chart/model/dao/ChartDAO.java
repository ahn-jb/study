package com.test.springStudy.chart.model.dao;

public class ChartDAO {

}

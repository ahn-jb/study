package com.test.springStudy.member.service;

public class MemberService {

}

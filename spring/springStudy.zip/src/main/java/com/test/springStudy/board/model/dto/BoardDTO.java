package com.test.springStudy.board.model.dto;

public class BoardDTO {

}

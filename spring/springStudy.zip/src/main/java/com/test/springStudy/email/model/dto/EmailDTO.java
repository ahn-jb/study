package com.test.springStudy.email.model.dto;

public class EmailDTO {

}

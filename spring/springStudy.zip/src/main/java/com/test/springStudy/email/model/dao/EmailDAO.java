package com.test.springStudy.email.model.dao;

public class EmailDAO {

}

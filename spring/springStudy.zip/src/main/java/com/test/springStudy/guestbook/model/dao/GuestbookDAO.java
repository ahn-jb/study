package com.test.springStudy.guestbook.model.dao;

public class GuestbookDAO {

}

package com.test.springStudy.guestbook.model.dto;

public class GuestbookDTO {

}

package com.test.springStudy.board.model.dao;

public class BoardDAO {

}

package com.test.springStudy.chart.model.dto;

public class ChartDTO {

}

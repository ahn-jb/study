package com.test.springStudy.guestbook.service;

public class GuestbookService {

}

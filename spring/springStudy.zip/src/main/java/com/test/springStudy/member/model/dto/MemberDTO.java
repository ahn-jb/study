package com.test.springStudy.member.model.dto;

public class MemberDTO {

}

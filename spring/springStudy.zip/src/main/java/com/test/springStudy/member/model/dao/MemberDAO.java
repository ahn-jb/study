package com.test.springStudy.member.model.dao;

public class MemberDAO {

}

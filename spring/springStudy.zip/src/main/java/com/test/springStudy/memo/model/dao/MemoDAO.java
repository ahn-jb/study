package com.test.springStudy.memo.model.dao;

public class MemoDAO {

}

package com.test.spring01;

public class Test07DTO {
	
	private String product_bunryu;
	private String product_name;
	private int product_price;
	private int harin;
	private String maid;
	private int harin_price;
	
	public String getProduct_bunryu() {
		return product_bunryu;
	}
	public void setProduct_bunryu(String product_bunryu) {
		this.product_bunryu = product_bunryu;
	}
	public String getProduct_name() {
		return product_name;
	}
	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}
	public int getProduct_price() {
		return product_price;
	}
	public void setProduct_price(int product_price) {
		this.product_price = product_price;
	}
	public int getHarin() {
		return harin;
	}
	public void setHarin(int harin) {
		this.harin = harin;
	}
	public String getMaid() {
		return maid;
	}
	public void setMaid(String maid) {
		this.maid = maid;
	}
	public int getHarin_price() {
		return harin_price;
	}
	public void setHarin_price(int harin_price) {
		this.harin_price = harin_price;
	}
	
	
	
	
}
